export interface Video {
  id: string;
  titleTR: string;
  titleEN: string;
  descriptionTR: string;
  descriptionEN: string;
  category: 'Seri' | 'Film' | 'Aksiyon' | 'Fantastik';
  coverUrl: string;
  videoUrl: string; // Direct link, YouTube link, dubz.co link, or indexedDB blob url
  isLocal: boolean;
  localFileKey?: string; // key in IndexedDB
  likes: number;
  views: number;
  duration?: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  videoId: string;
  userName: string;
  text: string;
  createdAt: string;
}

export type Language = 'TR' | 'EN';
