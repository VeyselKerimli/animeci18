import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Globe, Lock, ShieldAlert, Heart, Play, Film, MessageSquare, ChevronRight, AlertCircle, Info, Sparkles, LogIn, LogOut, User, Settings } from 'lucide-react';
import { ref, onValue, set, remove, update } from 'firebase/database';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { database, auth } from './firebase';
import { Video, Comment, Language } from './types';
import AgeGate from './components/AgeGate';
import AdminPanel from './components/AdminPanel';
import VideoGrid from './components/VideoGrid';
import VideoDetailModal from './components/VideoDetailModal';
import AuthModal from './components/AuthModal';

// Seed video database with high-quality real trailers
const SEED_VIDEOS: Video[] = [
  {
    id: 'seed_1',
    titleTR: 'Demon Slayer: Kimetsu no Yaiba - Mugen Train',
    titleEN: 'Demon Slayer: Kimetsu no Yaiba - Mugen Train',
    descriptionTR: 'İblis Keser - Tanjiro Kamado, arkadaşları ve güçlü alev sütunu Kyojuro Rengoku ile birlikte gizemli tren yolcularını iblislerin katliamından kurtarmak için ölümcül bir savaşa atılır.',
    descriptionEN: 'Tanjiro Kamado, along with his friends and the powerful Flame Hashira Kyojuro Rengoku, boards the Mugen Train to investigate a series of mysterious disappearances and defeat a lethal demon.',
    category: 'Aksiyon',
    coverUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=VQGCKyvzIM4',
    isLocal: false,
    likes: 342,
    views: 12045,
    createdAt: '2026-01-10T12:00:00.000Z',
  },
  {
    id: 'seed_2',
    titleTR: 'Attack on Titan (Shingeki no Kyojin) - Final Sezonu',
    titleEN: 'Attack on Titan (Shingeki no Kyojin) - Final Season',
    descriptionTR: 'Titana Saldırı - İnsanlığın devasa duvarlar arkasında esir düştüğü karanlık çağ sona eriyor. Eren Yeager, özgürlük uğruna tüm dünyayı karşısına alacak korkunç bir planı devreye sokuyor.',
    descriptionEN: 'The war for Paradis reaches its cataclysmic climax. Eren Yeager unleashes the Rumbling, turning from savior to the ultimate threat to humanity in his pursuit of absolute freedom.',
    category: 'Seri',
    coverUrl: 'https://images.unsplash.com/photo-1560169897-fc0cdbdfa4d5?w=600&auto=format&fit=crop&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=LHtd60T_7F8',
    isLocal: false,
    likes: 512,
    views: 19890,
    createdAt: '2026-02-15T15:30:00.000Z',
  },
  {
    id: 'seed_3',
    titleTR: 'Jujutsu Kaisen - Shibuya Olayı Arkı',
    titleEN: 'Jujutsu Kaisen - Shibuya Incident Arc',
    descriptionTR: 'Lanet Savaşları - Cadılar Bayramı gecesinde Shibuya sarsılıyor. Büyücüler dünyasının en güçlüsü Satoru Gojo tuzağa düşürülürken, insanlık ve lanetler arasındaki nihai savaş başlıyor.',
    descriptionEN: 'On October 31st, a barrier is cast over Shibuya. While the strongest sorcerer Satoru Gojo is targeted by a sinister trap, Yuji Itadori and his allies prepare for a brutal, all-out war.',
    category: 'Fantastik',
    coverUrl: 'https://images.unsplash.com/photo-1580477667995-2b94f01c9516?w=600&auto=format&fit=crop&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=O6qKo8PfXzo',
    isLocal: false,
    likes: 456,
    views: 15400,
    createdAt: '2026-03-20T18:45:00.000Z',
  },
  {
    id: 'seed_4',
    titleTR: 'Suzume (Suzume no Tojimari) - Resmi Film',
    titleEN: 'Suzume (Suzume no Tojimari) - Movie',
    descriptionTR: 'Suzume\'nin Kilidi - 17 yaşındaki Suzume, Japonya genelindeki yıkıcı kapıları kapatmak ve yaklaşan büyük felaketleri engellemek amacıyla gizemli Souta ile fantastik bir yolculuğa çıkar.',
    descriptionEN: '17-year-old Suzume discovers a mysterious door in the ruins of Kyushu. As doors begin opening all over Japan, releasing catastrophic forces, she must embark on a journey to lock them all.',
    category: 'Film',
    coverUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    videoUrl: 'https://www.youtube.com/watch?v=fvRccV64GMo',
    isLocal: false,
    likes: 289,
    views: 8900,
    createdAt: '2026-04-05T10:15:00.000Z',
  },
];

export default function App() {
  const [language, setLanguage] = useState<Language>('TR');
  const [isAgeVerified, setIsAgeVerified] = useState<boolean>(true);
  const [videos, setVideos] = useState<Video[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [likedVideoIds, setLikedVideoIds] = useState<Record<string, boolean>>({});

  // Auth / User states
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Navigation / UI States
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  // Load Initial Settings & LocalStorage Preferences
  useEffect(() => {
    // 1. Age Verification
    const verified = localStorage.getItem('animeci18_age_verified');
    setIsAgeVerified(verified === 'true');

    // 2. Language
    const savedLang = localStorage.getItem('animeci18_lang');
    if (savedLang === 'TR' || savedLang === 'EN') {
      setLanguage(savedLang);
    }
  }, []);

  // Sync with Firebase Auth and DB
  useEffect(() => {
    // A. Listen to Auth State
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      if (user) {
        // Load User Profile details
        const profileRef = ref(database, `users/${user.uid}`);
        const unsubscribeProfile = onValue(profileRef, (snapshot) => {
          const profile = snapshot.val();
          setUserProfile(profile);
          
          // Check admin status: email matches admin or profile states isAdmin
          const isUserAdmin = user.email === 'veyselogrt@gmail.com' || profile?.isAdmin === true;
          setIsAdmin(isUserAdmin);
        });

        // Load User Likes state
        const likesRef = ref(database, `users/${user.uid}/likes`);
        const unsubscribeLikes = onValue(likesRef, (snapshot) => {
          const likes = snapshot.val() || {};
          setLikedVideoIds(likes);
        });

        return () => {
          unsubscribeProfile();
          unsubscribeLikes();
        };
      } else {
        setUserProfile(null);
        setIsAdmin(false);
        setLikedVideoIds({});
      }
    });

    // B. Realtime Sync Videos
    const videosRef = ref(database, 'videos');
    const unsubscribeVideos = onValue(videosRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const list = Object.keys(data).map((key) => ({
          ...data[key],
          id: key,
        }));
        // Sort by createdAt descending
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setVideos(list);
      } else {
        // Seed initial videos if entirely empty
        SEED_VIDEOS.forEach((vid) => {
          set(ref(database, `videos/${vid.id}`), vid);
        });
      }
    });

    // C. Realtime Sync Comments
    const commentsRef = ref(database, 'comments');
    const unsubscribeComments = onValue(commentsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const list = Object.keys(data).map((key) => ({
          ...data[key],
          id: key,
        }));
        // Sort by createdAt descending
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setComments(list);
      } else {
        setComments([]);
      }
    });

    return () => {
      unsubscribeAuth();
      unsubscribeVideos();
      unsubscribeComments();
    };
  }, []);

  const handleAgeVerify = () => {
    setIsAgeVerified(true);
    localStorage.setItem('animeci18_age_verified', 'true');
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('animeci18_lang', lang);
  };

  // Video operations using Firebase RTDB
  const handleAddVideo = (newVideo: Video) => {
    set(ref(database, `videos/${newVideo.id}`), newVideo);
  };

  const handleUpdateVideo = (updatedVideo: Video) => {
    set(ref(database, `videos/${updatedVideo.id}`), updatedVideo);
    if (selectedVideo?.id === updatedVideo.id) {
      setSelectedVideo(updatedVideo);
    }
  };

  const handleDeleteVideo = (id: string) => {
    remove(ref(database, `videos/${id}`));
    if (selectedVideo?.id === id) {
      setSelectedVideo(null);
    }
  };

  // Interactive comments via Firebase RTDB
  const handleAddComment = (videoId: string, userName: string, text: string) => {
    const commentId = `comment_${Date.now()}`;
    const newComment: Comment = {
      id: commentId,
      videoId,
      userName,
      text,
      createdAt: new Date().toISOString(),
    };
    set(ref(database, `comments/${commentId}`), newComment);
  };

  // Likes toggle via Firebase RTDB
  const handleLikeVideo = (videoId: string) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }

    const isLiked = !!likedVideoIds[videoId];
    
    // Save liked state
    set(ref(database, `users/${currentUser.uid}/likes/${videoId}`), isLiked ? null : true);

    // Update total count
    const video = videos.find((v) => v.id === videoId);
    if (video) {
      const currentLikes = video.likes || 0;
      update(ref(database, `videos/${videoId}`), {
        likes: isLiked ? Math.max(0, currentLikes - 1) : currentLikes + 1,
      });
    }
  };

  // Video views increment using Firebase RTDB
  const handleSelectVideo = (video: Video) => {
    setSelectedVideo(video);
    
    // Increment views safely in the database
    const currentViews = video.views || 0;
    update(ref(database, `videos/${video.id}`), {
      views: currentViews + 1,
    });
  };

  // Real-time selected video tracker (so view/likes sync automatically while reading comments)
  const activeSelectedVideo = selectedVideo ? (videos.find((v) => v.id === selectedVideo.id) || selectedVideo) : null;

  // Generate mapped counts of comments for efficient grid loading
  const commentsCountMap: Record<string, number> = {};
  comments.forEach((c) => {
    commentsCountMap[c.videoId] = (commentsCountMap[c.videoId] || 0) + 1;
  });

  const activeComments = comments.filter((c) => c.videoId === activeSelectedVideo?.id);

  // Copy translations
  const t = {
    TR: {
      siteName: 'animeci18',
      premiumTag: 'Premium',
      home: 'Keşfet',
      all: 'Tümü',
      category: 'Kategoriler',
      series: 'Seri',
      movies: 'Film',
      action: 'Aksiyon',
      fantasy: 'Fantastik',
      heroSubtitle: 'Yetişkinlere özel premium anime ve video akış platformu. Sınırsız heyecan, yüksek kaliteli oynatıcı ve özgür topluluk.',
      bannerTag: 'PREMIUM SEÇKİSİ',
      latestUploads: 'Son Eklenen Videolar',
      footerDesc: 'animeci18, modern tasarımı ve gelişmiş tarayıcı teknolojileriyle kesintisiz bir izleme deneyimi sunar.',
      disclaimer: 'Tüm hakları saklıdır. +18 Yaş Sınırı Uygulanmaktadır.',
      adminPanelLabel: 'Yönetim',
    },
    EN: {
      siteName: 'animeci18',
      premiumTag: 'Premium',
      home: 'Browse',
      all: 'All',
      category: 'Categories',
      series: 'Series',
      movies: 'Movie',
      action: 'Action',
      fantasy: 'Fantasy',
      heroSubtitle: 'Premium anime and video streaming platform for adults. Unlimited excitement, high-quality player, and an open community.',
      bannerTag: 'PREMIUM PICK',
      latestUploads: 'Latest Videos',
      footerDesc: 'animeci18 offers an uninterrupted streaming experience powered by modern designs and web-technologies.',
      disclaimer: 'All rights reserved. Adult Content Warning +18 strictly enforced.',
      adminPanelLabel: 'Admin Panel',
    },
  }[language];

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col selection:bg-brand-primary selection:text-white">
      
      {/* Age verification overlay */}
      <AnimatePresence>
        {!isAgeVerified && (
          <AgeGate
            language={language}
            setLanguage={handleLanguageChange}
            onVerify={handleAgeVerify}
          />
        )}
      </AnimatePresence>

      {/* Main Header navigation */}
      <header className="sticky top-0 z-30 bg-[#050505]/85 backdrop-blur-md border-b border-white/5 py-4 px-6 md:px-12 flex items-center justify-between">
        <div className="flex items-center gap-1.5 cursor-pointer" onClick={() => setSelectedVideo(null)}>
          <span className="text-white font-black tracking-tighter text-2xl">
            animeci<span className="text-brand-primary">18</span>
          </span>
          <span className="bg-brand-primary/10 border border-brand-primary/30 text-brand-accent text-[10px] font-bold px-1.5 py-0.5 rounded tracking-widest uppercase">
            {t.premiumTag}
          </span>
        </div>

        {/* Global Toolbar */}
        <div className="flex items-center gap-4">
          {/* TR / EN Language Switcher */}
          <button
            onClick={() => handleLanguageChange(language === 'TR' ? 'EN' : 'TR')}
            className="flex items-center gap-1.5 bg-[#0F0F0F] hover:bg-[#141414] border border-white/5 hover:border-white/10 px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all duration-300 cursor-pointer"
            title={language === 'TR' ? 'Change to English' : 'Türkçeye Geç'}
          >
            <Globe className="w-3.5 h-3.5 text-brand-primary" />
            <span>{language === 'TR' ? 'EN' : 'TR'}</span>
          </button>

          {/* User Section */}
          {currentUser ? (
            <div className="flex items-center gap-3 bg-[#0F0F0F] border border-white/5 rounded-full pl-3.5 pr-2 py-1.5">
              <span className="text-xs text-gray-300 font-bold max-w-[100px] truncate">
                {userProfile?.name || currentUser.email.split('@')[0]}
              </span>
              
              {/* User Avatar */}
              <div className="w-7 h-7 rounded-full bg-brand-primary/20 border border-brand-primary/40 flex items-center justify-center text-brand-accent font-black text-xs uppercase shadow-[0_0_8px_rgba(255,85,0,0.2)]">
                {(userProfile?.name || currentUser.email)[0]}
              </div>

              {/* Secure discrete Admin button (Lock icon only visible once verified as Admin) */}
              {isAdmin && (
                <button
                  onClick={() => setIsAdminOpen(true)}
                  className="p-1.5 bg-[#141414] hover:bg-[#1A1A1A] text-brand-accent hover:text-brand-primary rounded-full transition-all cursor-pointer border border-white/5"
                  title={t.adminPanelLabel}
                >
                  <Settings className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Logout Button */}
              <button
                onClick={() => signOut(auth)}
                className="p-1.5 bg-red-950/20 text-red-400 hover:bg-red-950/40 hover:text-red-300 rounded-full transition-colors cursor-pointer"
                title={language === 'TR' ? 'Çıkış Yap' : 'Log Out'}
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAuthOpen(true)}
              className="flex items-center gap-1.5 bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_12px_rgba(255,85,0,0.3)] text-white text-xs font-bold px-4 py-2 rounded-full transition-all cursor-pointer transform active:scale-95"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{language === 'TR' ? 'Giriş Yap' : 'Login'}</span>
            </button>
          )}
        </div>
      </header>

      {/* Hero Showcase / Banner (Visible when no specific video is active and search is empty) */}
      <AnimatePresence mode="wait">
        {!selectedVideo && searchQuery === '' && selectedCategory === 'all' && (
          <motion.section
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="relative h-[400px] md:h-[500px] flex items-end px-6 md:px-12 py-16 overflow-hidden border-b border-white/5"
          >
            {/* Background cover (Using beautiful dark anime background photo) */}
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1200&auto=format&fit=crop&q=85')] bg-cover bg-center" />
            
            {/* High fidelity dark overlay gradients */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/70 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-[#050505]/40" />

            <div className="relative z-10 max-w-2xl">
              <span className="inline-flex items-center gap-1.5 bg-brand-primary/20 border border-brand-primary/40 text-brand-accent text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-widest mb-4">
                <Sparkles className="w-3.5 h-3.5 text-brand-primary" />
                {t.bannerTag}
              </span>

              <h1 className="text-4xl md:text-6xl font-black tracking-tight text-white mb-4 uppercase">
                {language === 'TR' ? 'Eşsiz Anime Evreni' : 'Unmatched Anime Realm'}
              </h1>
              
              <p className="text-gray-300 text-sm md:text-base leading-relaxed mb-6 font-medium">
                {t.heroSubtitle}
              </p>

              <div className="flex flex-wrap gap-3">
                {videos.length > 0 && (
                  <button
                    onClick={() => handleSelectVideo(videos[0])}
                    className="bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_20px_rgba(255,85,0,0.5)] font-bold px-6 py-3.5 rounded-xl transition-all duration-300 flex items-center gap-2 transform active:scale-95 text-sm"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>{language === 'TR' ? 'Hemen Başla' : 'Start Watching'}</span>
                  </button>
                )}
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Main Dashboard body */}
      <main className="flex-1 px-6 md:px-12 py-8 max-w-7xl w-full mx-auto">
        <AnimatePresence mode="wait">
          {selectedVideo ? (
            /* Immersive Detail Modal & Video Player view */
            <VideoDetailModal
              video={activeSelectedVideo || selectedVideo}
              language={language}
              onClose={() => setSelectedVideo(null)}
              onLike={handleLikeVideo}
              hasLiked={!!likedVideoIds[(activeSelectedVideo || selectedVideo).id]}
              comments={activeComments}
              onAddComment={handleAddComment}
              currentUser={currentUser}
              userProfile={userProfile}
              onAuthOpen={() => setIsAuthOpen(true)}
            />
          ) : (
            /* Standard Grid browsing view */
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              <VideoGrid
                videos={videos}
                language={language}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                onSelectVideo={handleSelectVideo}
                commentsMap={commentsCountMap}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Premium Footer */}
      <footer className="bg-[#0A0A0A] border-t border-white/5 py-12 px-6 md:px-12 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left space-y-2">
            <div className="flex items-center justify-center md:justify-start gap-1">
              <span className="text-white font-black tracking-tighter text-xl">
                animeci<span className="text-brand-primary">18</span>
              </span>
              <span className="text-[10px] bg-brand-primary/10 border border-brand-primary/20 text-brand-accent px-1.5 py-0.5 rounded tracking-widest font-extrabold uppercase">
                {t.premiumTag}
              </span>
            </div>
            <p className="text-xs text-gray-500 max-w-md leading-normal">
              {t.footerDesc}
            </p>
          </div>

          <div className="text-center md:text-right space-y-1.5">
            <p className="text-xs text-gray-500 font-semibold tracking-wide">
              {t.disclaimer}
            </p>
            <p className="text-[11px] text-gray-600 font-medium">
              &copy; {new Date().getFullYear()} animeci18. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Admin Panel container modal */}
      <AnimatePresence>
        {isAdminOpen && (
          <AdminPanel
            language={language}
            videos={videos}
            onAddVideo={handleAddVideo}
            onUpdateVideo={handleUpdateVideo}
            onDeleteVideo={handleDeleteVideo}
            isOpen={isAdminOpen}
            onClose={() => setIsAdminOpen(false)}
            isAdmin={isAdmin}
            setIsAdmin={setIsAdmin}
          />
        )}
      </AnimatePresence>

      {/* Auth Modal container */}
      <AnimatePresence>
        {isAuthOpen && (
          <AuthModal
            isOpen={isAuthOpen}
            onClose={() => setIsAuthOpen(false)}
            language={language}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
