import React, { useState, useEffect, useRef } from 'react';
import { Film, Play, AlertTriangle, Eye, Heart, Share2, CornerDownRight } from 'lucide-react';
import { Video, Language } from '../types';
import { getVideoBlob } from '../db';

interface VideoPlayerProps {
  video: Video;
  language: Language;
  onLike: () => void;
  hasLiked: boolean;
}

export default function VideoPlayer({ video, language, onLike, hasLiked }: VideoPlayerProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [srcUrl, setSrcUrl] = useState<string>('');
  const [videoType, setVideoType] = useState<'html5' | 'youtube' | 'dubz' | 'unknown'>('html5');
  const videoRef = useRef<HTMLVideoElement>(null);

  // Parse URLs
  useEffect(() => {
    let active = true;
    let localUrl = '';

    const resolveUrl = async () => {
      setLoading(true);
      setError(false);

      if (video.isLocal && video.localFileKey) {
        try {
          const blob = await getVideoBlob(video.localFileKey);
          if (blob && active) {
            localUrl = URL.createObjectURL(blob);
            setSrcUrl(localUrl);
            setVideoType('html5');
            setLoading(false);
          } else if (active) {
            setError(true);
            setLoading(false);
          }
        } catch (e) {
          console.error('Error fetching IndexedDB blob:', e);
          if (active) {
            setError(true);
            setLoading(false);
          }
        }
        return;
      }

      const url = video.videoUrl;

      // Check YouTube
      const ytRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/ ]{11})/;
      const ytMatch = url.match(ytRegex);
      if (ytMatch) {
        setSrcUrl(`https://www.youtube.com/embed/${ytMatch[1]}?autoplay=1&rel=0&modestbranding=1`);
        setVideoType('youtube');
        setLoading(false);
        return;
      }

      // Check dubz.co
      const dubzRegex = /dubz\.co\/(?:v|c|e|embed)\/([a-zA-Z0-9]+)/;
      const dubzMatch = url.match(dubzRegex);
      if (dubzMatch) {
        // Embed format for dubz.co is https://dubz.co/e/ID or https://dubz.co/embed/ID
        setSrcUrl(`https://dubz.co/e/${dubzMatch[1]}`);
        setVideoType('dubz');
        setLoading(false);
        return;
      }

      // Default to HTML5 direct video link
      setSrcUrl(url);
      setVideoType('html5');
      setLoading(false);
    };

    resolveUrl();

    return () => {
      active = false;
      if (localUrl) {
        URL.revokeObjectURL(localUrl);
      }
    };
  }, [video]);

  const handleShare = () => {
    const text = language === 'TR' 
      ? `Animeci18 Premium'da harika bir video izliyorum: ${video.titleTR}`
      : `Watching an awesome video on Animeci18 Premium: ${video.titleEN}`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Animeci18 Premium',
        text: text,
        url: window.location.href
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert(language === 'TR' ? 'Link panoya kopyalandı!' : 'Link copied to clipboard!');
    }
  };

  return (
    <div className="w-full flex flex-col">
      {/* Aspect ratio frame for the video player */}
      <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-white/5 shadow-2xl group">
        {/* Cinema ambient light behind the player */}
        <div className="absolute inset-0 bg-gradient-to-t from-brand-primary/10 via-transparent to-transparent opacity-60 pointer-events-none" />

        {loading && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#050505]">
            <Film className="w-10 h-10 text-brand-primary animate-spin mb-3" />
            <span className="text-sm font-medium text-gray-400">
              {language === 'TR' ? 'Video oynatıcı yükleniyor...' : 'Loading video player...'}
            </span>
          </div>
        )}

        {error ? (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#0F0F0F] text-center px-6">
            <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
            <h3 className="text-lg font-bold text-white mb-2">
              {language === 'TR' ? 'Video Yüklenemedi' : 'Failed to Load Video'}
            </h3>
            <p className="text-sm text-gray-400 max-w-md">
              {language === 'TR'
                ? 'Bu video kaynağına şu anda erişilemiyor veya yerel dosya silinmiş olabilir.'
                : 'This video source is currently unreachable or the local file might have been deleted.'}
            </p>
          </div>
        ) : (
          <>
            {videoType === 'html5' && srcUrl && (
              <video
                ref={videoRef}
                src={srcUrl}
                controls
                autoPlay
                className="w-full h-full object-contain rounded-2xl relative z-0"
                onError={() => setError(true)}
                onLoadedData={() => setLoading(false)}
              />
            )}

            {videoType === 'youtube' && srcUrl && (
              <iframe
                src={srcUrl}
                title={video.titleEN}
                className="w-full h-full rounded-2xl relative z-0 border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            )}

            {videoType === 'dubz' && srcUrl && (
              <iframe
                src={srcUrl}
                title={video.titleEN}
                className="w-full h-full rounded-2xl relative z-0 border-0"
                allow="autoplay; fullscreen"
                allowFullScreen
              />
            )}
          </>
        )}
      </div>

      {/* Video Details Bar */}
      <div className="mt-5 p-5 md:p-6 bg-[#0F0F0F]/90 border border-white/5 rounded-2xl backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="flex-1">
            {/* Category tag */}
            <span className="inline-block bg-brand-primary/10 border border-brand-primary/20 text-brand-accent text-xs px-2.5 py-1 rounded-md font-bold uppercase tracking-wider mb-2.5">
              {language === 'TR' ? video.category : {
                Seri: 'Series',
                Film: 'Movie',
                Aksiyon: 'Action',
                Fantastik: 'Fantasy'
              }[video.category]}
            </span>

            <h1 className="text-xl md:text-2xl font-black text-white tracking-tight mb-2">
              {language === 'TR' ? video.titleTR : video.titleEN}
            </h1>

            <div className="flex items-center gap-4 text-xs text-gray-400 font-medium">
              <span className="flex items-center gap-1">
                <Eye className="w-4 h-4 text-gray-500" />
                {video.views.toLocaleString()} {language === 'TR' ? 'izlenme' : 'views'}
              </span>
              <span>•</span>
              <span>{new Date(video.createdAt).toLocaleDateString(language === 'TR' ? 'tr-TR' : 'en-US')}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onLike}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-bold tracking-tight transition-all duration-300 ${
                hasLiked
                  ? 'bg-brand-primary/20 border-brand-primary text-brand-accent shadow-[0_0_15px_rgba(255,85,0,0.15)]'
                  : 'bg-[#141414] border-white/5 hover:border-white/10 hover:bg-white/5 text-gray-300 hover:text-white'
              }`}
            >
              <Heart className={`w-4 h-4 ${hasLiked ? 'fill-current text-brand-primary' : ''}`} />
              <span>{video.likes}</span>
            </button>
            <button
              onClick={handleShare}
              className="flex items-center justify-center w-11 h-11 bg-[#141414] border border-white/5 hover:border-white/10 hover:bg-white/5 rounded-xl text-gray-300 hover:text-white transition-all"
              title={language === 'TR' ? 'Paylaş' : 'Share'}
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Description panel */}
        <div className="mt-5 border-t border-white/5 pt-5 text-sm md:text-base text-gray-300 leading-relaxed max-w-none">
          <p className="whitespace-pre-line">
            {language === 'TR' ? video.descriptionTR : video.descriptionEN}
          </p>
        </div>
      </div>
    </div>
  );
}
