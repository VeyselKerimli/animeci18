import React from 'react';
import { motion } from 'motion/react';
import { Search, Play, Star, Calendar, MessageSquare, Heart } from 'lucide-react';
import { Video, Language } from '../types';

interface VideoGridProps {
  videos: Video[];
  language: Language;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  onSelectVideo: (video: Video) => void;
  commentsMap: Record<string, number>; // counts of comments per video
}

export default function VideoGrid({
  videos,
  language,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  onSelectVideo,
  commentsMap,
}: VideoGridProps) {
  // Categories for switcher
  const categories = [
    { key: 'all', TR: 'Tümü', EN: 'All' },
    { key: 'Seri', TR: 'Seri', EN: 'Series' },
    { key: 'Film', TR: 'Film', EN: 'Movie' },
    { key: 'Aksiyon', TR: 'Aksiyon', EN: 'Action' },
    { key: 'Fantastik', TR: 'Fantastik', EN: 'Fantasy' },
  ];

  // Filtering
  const filteredVideos = videos.filter((video) => {
    const title = language === 'TR' ? video.titleTR : video.titleEN;
    const desc = language === 'TR' ? video.descriptionTR : video.descriptionEN;
    const matchesSearch =
      title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      desc.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === 'all' || video.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const t = {
    TR: {
      searchPlaceholder: 'Anime veya video ara...',
      allResults: 'Tüm İçerikler',
      noResults: 'Aradığınız kritere uygun video bulunamadı.',
      totalCount: 'video bulundu',
      playNow: 'Hemen İzle',
      viewDetails: 'Detaylar ve Yorumlar',
    },
    EN: {
      searchPlaceholder: 'Search anime or videos...',
      allResults: 'All Content',
      noResults: 'No videos found matching your criteria.',
      totalCount: 'videos found',
      playNow: 'Watch Now',
      viewDetails: 'Details & Comments',
    },
  }[language];

  // Motion Container variants
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 25 } },
  };

  return (
    <div className="w-full">
      {/* Category Filter & Search Bar Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all duration-300 ${
                selectedCategory === cat.key
                  ? 'bg-brand-primary text-white shadow-[0_0_15px_rgba(255,85,0,0.3)]'
                  : 'bg-[#0F0F0F] border border-white/5 text-gray-400 hover:text-white hover:bg-[#141414] hover:border-white/10'
              }`}
            >
              {language === 'TR' ? cat.TR : cat.EN}
            </button>
          ))}
        </div>

        {/* Real-time Search Input */}
        <div className="relative w-full md:max-w-xs">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full bg-[#0F0F0F]/80 backdrop-blur-md border border-white/5 focus:border-brand-primary focus:outline-none rounded-full pl-11 pr-4 py-3 text-sm text-white placeholder-gray-500 transition-all"
          />
        </div>
      </div>

      {/* Videos List Header Info */}
      <div className="flex items-center justify-between mb-5 px-1">
        <h3 className="text-base font-bold text-gray-300">
          {selectedCategory === 'all'
            ? t.allResults
            : language === 'TR'
            ? selectedCategory
            : {
                Seri: 'Series',
                Film: 'Movie',
                Aksiyon: 'Action',
                Fantastik: 'Fantasy',
              }[selectedCategory]}
        </h3>
        <span className="text-xs text-gray-500 font-medium">
          {filteredVideos.length} {t.totalCount}
        </span>
      </div>

      {/* Grid */}
      {filteredVideos.length === 0 ? (
        <div className="text-center py-20 bg-[#0F0F0F]/40 border border-white/5 rounded-2xl p-8">
          <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 font-medium">{t.noResults}</p>
        </div>
      ) : (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6"
        >
          {filteredVideos.map((video) => {
            const commentCount = commentsMap[video.id] || 0;
            return (
              <motion.div
                key={video.id}
                variants={itemVariants}
                onClick={() => onSelectVideo(video)}
                className="group relative bg-[#0F0F0F] rounded-xl overflow-hidden border border-white/5 hover:border-brand-primary/40 cursor-pointer shadow-lg transition-all duration-300 hover:-translate-y-1.5"
              >
                {/* Image Wrapper */}
                <div className="relative aspect-[3/4] w-full overflow-hidden bg-zinc-900">
                  <img
                    src={video.coverUrl}
                    alt={language === 'TR' ? video.titleTR : video.titleEN}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />

                  {/* Dark Vignette / Hover overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10 opacity-70 group-hover:opacity-90 transition-opacity duration-300" />

                  {/* Play Button Icon overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-12 h-12 rounded-full bg-brand-primary flex items-center justify-center shadow-[0_0_20px_rgba(255,85,0,0.6)] transform scale-75 group-hover:scale-100 transition-transform duration-300">
                      <Play className="w-5 h-5 text-white fill-current translate-x-0.5" />
                    </div>
                  </div>

                  {/* Category Pill Tag (top-left) */}
                  <div className="absolute top-3 left-3 z-10">
                    <span className="bg-black/70 backdrop-blur-md border border-white/10 text-[10px] font-bold uppercase tracking-wider text-brand-accent px-2 py-0.5 rounded">
                      {language === 'TR' ? video.category : {
                        Seri: 'Series',
                        Film: 'Movie',
                        Aksiyon: 'Action',
                        Fantastik: 'Fantasy'
                      }[video.category]}
                    </span>
                  </div>

                  {/* Top-Right Tag indicating Local File */}
                  {video.isLocal && (
                    <div className="absolute top-3 right-3 z-10">
                      <span className="bg-cyan-950/80 backdrop-blur-md border border-cyan-500/30 text-[10px] font-bold uppercase tracking-wider text-cyan-400 px-2 py-0.5 rounded">
                        LOCAL
                      </span>
                    </div>
                  )}

                  {/* Metadata over bottom of thumbnail */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[10px] font-bold text-gray-400">
                    <div className="flex items-center gap-1.5">
                      <Heart className="w-3.5 h-3.5 text-brand-primary" />
                      <span>{video.likes}</span>
                    </div>
                    {commentCount > 0 && (
                      <div className="flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-gray-400" />
                        <span>{commentCount}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Info block */}
                <div className="p-4 flex flex-col">
                  <h4 className="text-sm font-bold text-white tracking-tight line-clamp-1 group-hover:text-brand-accent transition-colors">
                    {language === 'TR' ? video.titleTR : video.titleEN}
                  </h4>
                  <p className="text-xs text-gray-500 line-clamp-2 mt-1 leading-relaxed font-medium">
                    {language === 'TR' ? video.descriptionTR : video.descriptionEN}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}
    </div>
  );
}
