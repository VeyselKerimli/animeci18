import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';
import { Lock, Plus, Trash, Edit, X, Upload, Link as LinkIcon, CheckCircle, AlertCircle, Film, Languages } from 'lucide-react';
import { Video, Language } from '../types';
import { saveVideoBlob, deleteVideoBlob } from '../db';

interface AdminPanelProps {
  language: Language;
  videos: Video[];
  onAddVideo: (video: Video) => void;
  onUpdateVideo: (video: Video) => void;
  onDeleteVideo: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
}

export default function AdminPanel({
  language,
  videos,
  onAddVideo,
  onUpdateVideo,
  onDeleteVideo,
  isOpen,
  onClose,
  isAdmin,
  setIsAdmin,
}: AdminPanelProps) {
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<'list' | 'add'>('list');
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);

  // Form State
  const [titleTR, setTitleTR] = useState('');
  const [titleEN, setTitleEN] = useState('');
  const [descTR, setDescTR] = useState('');
  const [descEN, setDescEN] = useState('');
  const [category, setCategory] = useState<'Seri' | 'Film' | 'Aksiyon' | 'Fantastik'>('Seri');
  const [coverUrl, setCoverUrl] = useState('');
  const [videoSourceType, setVideoSourceType] = useState<'url' | 'local'>('url');
  const [videoUrl, setVideoUrl] = useState('');
  const [localFile, setLocalFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = {
    TR: {
      adminLogin: 'Yönetici Girişi',
      passPlaceholder: 'Yönetici Şifresi',
      login: 'Giriş Yap',
      wrongPass: 'Hatalı şifre!',
      panelTitle: 'Animeci18 Yönetim Paneli',
      videoList: 'Video Listesi',
      addNewVideo: 'Yeni Video Ekle',
      editVideo: 'Videoyu Düzenle',
      titleTR: 'Başlık (Türkçe)',
      titleEN: 'Başlık (İngilizce)',
      descTR: 'Açıklama (Türkçe)',
      descEN: 'Açıklama (İngilizce)',
      cat: 'Kategori',
      cover: 'Kapak Görseli URL',
      videoType: 'Video Kaynak Türü',
      webUrl: 'İnternet Linki (Direct MP4, YouTube, dubz.co)',
      localFile: 'Yerel Dosya Yükle (IndexedDB)',
      chooseFile: 'Bir video dosyası seçin veya sürükleyin',
      fileSelected: 'Dosya seçildi:',
      uploading: 'IndexedDB veritabanına yazılıyor, lütfen bekleyin...',
      save: 'Kaydet',
      cancel: 'İptal',
      actions: 'İşlemler',
      deleteConfirm: 'Bu videoyu silmek istediğinize emin misiniz? (Yerel dosyalar kalıcı olarak silinecektir)',
      success: 'Başarıyla kaydedildi!',
      missingFields: 'Lütfen tüm alanları doldurun.',
      categories: {
        Seri: 'Seri',
        Film: 'Film',
        Aksiyon: 'Aksiyon',
        Fantastik: 'Fantastik',
      },
    },
    EN: {
      adminLogin: 'Admin Login',
      passPlaceholder: 'Admin Password',
      login: 'Login',
      wrongPass: 'Incorrect password!',
      panelTitle: 'Animeci18 Admin Control Panel',
      videoList: 'Video List',
      addNewVideo: 'Add New Video',
      editVideo: 'Edit Video',
      titleTR: 'Title (Turkish)',
      titleEN: 'Title (English)',
      descTR: 'Description (Turkish)',
      descEN: 'Description (English)',
      cat: 'Category',
      cover: 'Cover Image URL',
      videoType: 'Video Source Type',
      webUrl: 'Web URL (Direct MP4, YouTube, dubz.co)',
      localFile: 'Upload Local File (IndexedDB)',
      chooseFile: 'Select or drag and drop a video file',
      fileSelected: 'File selected:',
      uploading: 'Writing to IndexedDB database, please wait...',
      save: 'Save',
      cancel: 'Cancel',
      actions: 'Actions',
      deleteConfirm: 'Are you sure you want to delete this video? (Local files will be deleted permanently)',
      success: 'Saved successfully!',
      missingFields: 'Please fill in all fields.',
      categories: {
        Seri: 'Series',
        Film: 'Movie',
        Aksiyon: 'Action',
        Fantastik: 'Fantasy',
      },
    },
  }[language];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'Veysel123') {
      setIsAdmin(true);
      setLoginError('');
      setPassword('');
    } else {
      setLoginError(t.wrongPass);
    }
  };

  const handleLogout = () => {
    signOut(auth);
    onClose();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setLocalFile(e.target.files[0]);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setUploadProgress('');

    const currentTitleTR = titleTR.trim();
    const currentTitleEN = titleEN.trim();
    const currentDescTR = descTR.trim();
    const currentDescEN = descEN.trim();
    const currentCoverUrl = coverUrl.trim() || 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500';

    if (!currentTitleTR || !currentTitleEN || !currentDescTR || !currentDescEN) {
      setErrorMessage(t.missingFields);
      return;
    }

    let finalVideoUrl = videoUrl;
    let isLocal = false;
    let localFileKey = editingVideo?.localFileKey || '';

    if (videoSourceType === 'local') {
      if (localFile) {
        setUploadProgress(t.uploading);
        const fileKey = `local_video_${Date.now()}`;
        try {
          await saveVideoBlob(fileKey, localFile);
          finalVideoUrl = fileKey; // Store key as the link indicator
          isLocal = true;
          localFileKey = fileKey;

          // If updating and had previous local key, delete previous to save space
          if (editingVideo?.isLocal && editingVideo.localFileKey) {
            await deleteVideoBlob(editingVideo.localFileKey);
          }
        } catch (err) {
          setErrorMessage('IndexedDB write failed: ' + String(err));
          setUploadProgress('');
          return;
        }
      } else if (editingVideo && editingVideo.isLocal) {
        // Keep existing local video
        isLocal = true;
        finalVideoUrl = editingVideo.videoUrl;
      } else {
        setErrorMessage(language === 'TR' ? 'Lütfen bir video dosyası seçin.' : 'Please select a video file.');
        return;
      }
    } else {
      if (!videoUrl.trim()) {
        setErrorMessage(t.missingFields);
        return;
      }
      isLocal = false;
      localFileKey = '';
      // If was previously local, delete previous blob to free storage
      if (editingVideo?.isLocal && editingVideo.localFileKey) {
        try {
          await deleteVideoBlob(editingVideo.localFileKey);
        } catch (e) {
          console.error(e);
        }
      }
    }

    if (editingVideo) {
      const updated: Video = {
        ...editingVideo,
        titleTR: currentTitleTR,
        titleEN: currentTitleEN,
        descriptionTR: currentDescTR,
        descriptionEN: currentDescEN,
        category,
        coverUrl: currentCoverUrl,
        videoUrl: finalVideoUrl,
        isLocal,
        localFileKey,
      };
      onUpdateVideo(updated);
    } else {
      const added: Video = {
        id: `video_${Date.now()}`,
        titleTR: currentTitleTR,
        titleEN: currentTitleEN,
        descriptionTR: currentDescTR,
        descriptionEN: currentDescEN,
        category,
        coverUrl: currentCoverUrl,
        videoUrl: finalVideoUrl,
        isLocal,
        localFileKey,
        likes: 0,
        views: 0,
        createdAt: new Date().toISOString(),
      };
      onAddVideo(added);
    }

    // Reset Form
    resetForm();
    setActiveTab('list');
  };

  const resetForm = () => {
    setTitleTR('');
    setTitleEN('');
    setDescTR('');
    setDescEN('');
    setCategory('Seri');
    setCoverUrl('');
    setVideoSourceType('url');
    setVideoUrl('');
    setLocalFile(null);
    setUploadProgress('');
    setErrorMessage('');
    setEditingVideo(null);
  };

  const startEdit = (video: Video) => {
    setEditingVideo(video);
    setTitleTR(video.titleTR);
    setTitleEN(video.titleEN);
    setDescTR(video.descriptionTR);
    setDescEN(video.descriptionEN);
    setCategory(video.category);
    setCoverUrl(video.coverUrl);
    setVideoSourceType(video.isLocal ? 'local' : 'url');
    setVideoUrl(video.isLocal ? '' : video.videoUrl);
    setLocalFile(null);
    setActiveTab('add');
  };

  const handleDelete = async (video: Video) => {
    if (confirm(t.deleteConfirm)) {
      if (video.isLocal && video.localFileKey) {
        try {
          await deleteVideoBlob(video.localFileKey);
        } catch (e) {
          console.error(e);
        }
      }
      onDeleteVideo(video.id);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-4xl bg-[#0F0F0F] border border-white/10 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#141414] border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <Lock className="w-5 h-5 text-brand-primary" />
            <h2 className="text-lg font-bold tracking-tight text-white">
              {isAdmin ? t.panelTitle : t.adminLogin}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Container */}
        <div className="flex-1 overflow-y-auto p-6">
          {!isAdmin ? (
            /* Login Form */
            <form onSubmit={handleLogin} className="max-w-md mx-auto py-12 flex flex-col items-center">
              <div className="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center mb-6">
                <Lock className="w-6 h-6 text-brand-primary" />
              </div>
              <div className="w-full mb-4">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.passPlaceholder}
                  className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3.5 text-center text-white tracking-widest transition-all"
                  autoFocus
                />
              </div>
              {loginError && (
                <p className="text-red-500 text-sm mb-4 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {loginError}
                </p>
              )}
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_15px_rgba(255,85,0,0.3)] text-white font-bold py-3.5 rounded-xl transition-all"
              >
                {t.login}
              </button>
            </form>
          ) : (
            /* Admin Dashboard */
            <div>
              {/* Navigation Tabs */}
              <div className="flex gap-2 border-b border-white/5 pb-4 mb-6">
                <button
                  onClick={() => {
                    setActiveTab('list');
                    resetForm();
                  }}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    activeTab === 'list'
                      ? 'bg-brand-primary text-white shadow-[0_0_10px_rgba(255,85,0,0.2)]'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {t.videoList} ({videos.length})
                </button>
                <button
                  onClick={() => {
                    setActiveTab('add');
                    setEditingVideo(null);
                  }}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-1.5 ${
                    activeTab === 'add' && !editingVideo
                      ? 'bg-brand-primary text-white shadow-[0_0_10px_rgba(255,85,0,0.2)]'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Plus className="w-4 h-4" />
                  {t.addNewVideo}
                </button>
                {editingVideo && (
                  <div className="bg-brand-accent/20 border border-brand-accent/40 text-brand-accent px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5">
                    <Edit className="w-4 h-4" />
                    {t.editVideo}
                  </div>
                )}

                <button
                  onClick={handleLogout}
                  className="ml-auto px-3 py-1.5 rounded-lg text-xs bg-red-950/40 border border-red-900/30 text-red-400 hover:bg-red-900/40 hover:text-red-300 transition-all"
                >
                  {language === 'TR' ? 'Güvenli Çıkış' : 'Secure Logout'}
                </button>
              </div>

              {activeTab === 'list' ? (
                /* Video List Table */
                <div className="overflow-x-auto border border-white/5 rounded-xl">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-[#141414] text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-white/5">
                        <th className="px-5 py-4">{language === 'TR' ? 'Görsel' : 'Cover'}</th>
                        <th className="px-5 py-4">{language === 'TR' ? 'Başlık (TR / EN)' : 'Title (TR / EN)'}</th>
                        <th className="px-5 py-4">{t.cat}</th>
                        <th className="px-5 py-4">{language === 'TR' ? 'Tür' : 'Source'}</th>
                        <th className="px-5 py-4 text-right">{t.actions}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-sm text-gray-300">
                      {videos.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-5 py-8 text-center text-gray-500">
                            {language === 'TR' ? 'Henüz video eklenmemiş.' : 'No videos added yet.'}
                          </td>
                        </tr>
                      ) : (
                        videos.map((video) => (
                          <tr key={video.id} className="hover:bg-white/5 transition-colors">
                            <td className="px-5 py-3">
                              <img
                                src={video.coverUrl}
                                alt="Cover"
                                className="w-12 h-16 object-cover rounded-md border border-white/10 bg-zinc-900"
                              />
                            </td>
                            <td className="px-5 py-3 max-w-xs">
                              <div className="font-semibold text-white truncate">{video.titleTR}</div>
                              <div className="text-xs text-gray-400 truncate">{video.titleEN}</div>
                            </td>
                            <td className="px-5 py-3">
                              <span className="bg-brand-primary/10 border border-brand-primary/20 text-brand-accent text-xs px-2 py-1 rounded-md font-medium">
                                {t.categories[video.category]}
                              </span>
                            </td>
                            <td className="px-5 py-3">
                              {video.isLocal ? (
                                <span className="bg-cyan-950/50 border border-cyan-800/40 text-cyan-400 text-xs px-2 py-1 rounded-md font-medium">
                                  Local (IndexedDB)
                                </span>
                              ) : (
                                <span className="bg-indigo-950/50 border border-indigo-800/40 text-indigo-400 text-xs px-2 py-1 rounded-md font-medium truncate max-w-[120px] inline-block">
                                  {video.videoUrl.includes('youtube')
                                    ? 'YouTube'
                                    : video.videoUrl.includes('dubz.co')
                                    ? 'dubz.co'
                                    : 'Web Link'}
                                </span>
                              )}
                            </td>
                            <td className="px-5 py-3 text-right">
                              <div className="flex justify-end gap-2">
                                <button
                                  onClick={() => startEdit(video)}
                                  className="p-1.5 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                                  title={language === 'TR' ? 'Düzenle' : 'Edit'}
                                >
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleDelete(video)}
                                  className="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors"
                                  title={language === 'TR' ? 'Sil' : 'Delete'}
                                >
                                  <Trash className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              ) : (
                /* Add / Edit Video Form */
                <form onSubmit={handleFormSubmit} className="space-y-6 max-w-2xl mx-auto">
                  {errorMessage && (
                    <div className="bg-red-950/40 border border-red-900/30 text-red-400 p-4 rounded-xl flex items-center gap-3 text-sm">
                      <AlertCircle className="w-5 h-5 flex-shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  {uploadProgress && (
                    <div className="bg-brand-primary/10 border border-brand-primary/20 text-brand-accent p-4 rounded-xl flex items-center gap-3 text-sm animate-pulse">
                      <Film className="w-5 h-5 animate-spin text-brand-primary" />
                      <span>{uploadProgress}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Title TR */}
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">
                        {t.titleTR} *
                      </label>
                      <input
                        type="text"
                        value={titleTR}
                        onChange={(e) => setTitleTR(e.target.value)}
                        className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3 text-white transition-all text-sm"
                        placeholder="Örn: Shingeki no Kyojin - Sezon 1 Bölüm 1"
                        required
                      />
                    </div>
                    {/* Title EN */}
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">
                        {t.titleEN} *
                      </label>
                      <input
                        type="text"
                        value={titleEN}
                        onChange={(e) => setTitleEN(e.target.value)}
                        className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3 text-white transition-all text-sm"
                        placeholder="e.g. Attack on Titan - Season 1 Episode 1"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Description TR */}
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">
                        {t.descTR} *
                      </label>
                      <textarea
                        value={descTR}
                        onChange={(e) => setDescTR(e.target.value)}
                        className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3 text-white transition-all text-sm h-28 resize-none"
                        placeholder="Anime konusu ve bölüm açıklaması..."
                        required
                      />
                    </div>
                    {/* Description EN */}
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">
                        {t.descEN} *
                      </label>
                      <textarea
                        value={descEN}
                        onChange={(e) => setDescEN(e.target.value)}
                        className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3 text-white transition-all text-sm h-28 resize-none"
                        placeholder="Anime plot and episode description..."
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Category Selection */}
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">
                        {t.cat} *
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value as any)}
                        className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3 text-white transition-all text-sm appearance-none cursor-pointer"
                      >
                        <option value="Seri">{t.categories.Seri}</option>
                        <option value="Film">{t.categories.Film}</option>
                        <option value="Aksiyon">{t.categories.Aksiyon}</option>
                        <option value="Fantastik">{t.categories.Fantastik}</option>
                      </select>
                    </div>

                    {/* Cover URL */}
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-2 tracking-wider">
                        {t.cover}
                      </label>
                      <input
                        type="url"
                        value={coverUrl}
                        onChange={(e) => setCoverUrl(e.target.value)}
                        className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3 text-white transition-all text-sm"
                        placeholder="https://gorsel-linki.com/kapak.jpg"
                      />
                    </div>
                  </div>

                  {/* Video Source Picker */}
                  <div className="border-t border-white/5 pt-6">
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-3 tracking-wider">
                      {t.videoType}
                    </label>
                    <div className="flex gap-4 mb-4">
                      <button
                        type="button"
                        onClick={() => setVideoSourceType('url')}
                        className={`flex-1 flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl border text-sm font-semibold transition-all ${
                          videoSourceType === 'url'
                            ? 'bg-brand-primary/10 border-brand-primary text-white shadow-[0_0_15px_rgba(255,85,0,0.1)]'
                            : 'bg-[#141414] border-white/5 text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <LinkIcon className="w-4 h-4" />
                        {t.webUrl}
                      </button>
                      <button
                        type="button"
                        onClick={() => setVideoSourceType('local')}
                        className={`flex-1 flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl border text-sm font-semibold transition-all ${
                          videoSourceType === 'local'
                            ? 'bg-brand-primary/10 border-brand-primary text-white shadow-[0_0_15px_rgba(255,85,0,0.1)]'
                            : 'bg-[#141414] border-white/5 text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <Upload className="w-4 h-4" />
                        {t.localFile}
                      </button>
                    </div>

                    {videoSourceType === 'url' ? (
                      /* URL Inputs */
                      <div className="space-y-2">
                        <input
                          type="text"
                          value={videoUrl}
                          onChange={(e) => setVideoUrl(e.target.value)}
                          className="w-full bg-[#1A1A1A] border border-white/10 focus:border-brand-primary focus:outline-none rounded-xl px-4 py-3.5 text-white transition-all text-sm font-mono"
                          placeholder="https://dubz.co/v/abc1234 or direct MP4 URL"
                          required={videoSourceType === 'url'}
                        />
                        <p className="text-xs text-gray-500 pl-1 leading-relaxed">
                          💡 dubz.co video linklerini (örn. <code>https://dubz.co/c/1234a5</code> veya <code>https://dubz.co/v/1234a5</code>) doğrudan yapıştırabilirsiniz. Sistem bunları akıllıca tespit edip gömer.
                        </p>
                      </div>
                    ) : (
                      /* File Drag-and-drop / Upload Input */
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-white/10 hover:border-brand-primary/50 bg-[#141414] hover:bg-[#1A1A1A] rounded-2xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center"
                      >
                        <input
                          type="file"
                          ref={fileInputRef}
                          onChange={handleFileChange}
                          accept="video/mp4, video/webm, video/ogg"
                          className="hidden"
                        />
                        <Upload className="w-10 h-10 text-brand-primary mb-3" />
                        <span className="text-sm font-semibold text-gray-300">
                          {localFile ? `${t.fileSelected} ${localFile.name}` : t.chooseFile}
                        </span>
                        {localFile && (
                          <span className="text-xs text-brand-accent mt-2 font-mono">
                            ({(localFile.size / (1024 * 1024)).toFixed(2)} MB)
                          </span>
                        )}
                        {!localFile && editingVideo?.isLocal && (
                          <span className="text-xs text-cyan-400 mt-2 font-medium">
                            ✓ {language === 'TR' ? 'Mevcut yerel video korunuyor' : 'Existing local video is preserved'}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Actions buttons */}
                  <div className="flex gap-3 justify-end border-t border-white/5 pt-6">
                    <button
                      type="button"
                      onClick={() => {
                        resetForm();
                        setActiveTab('list');
                      }}
                      className="px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white font-semibold transition-all text-sm"
                    >
                      {t.cancel}
                    </button>
                    <button
                      type="submit"
                      disabled={!!uploadProgress}
                      className="px-8 py-3 rounded-xl bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_15px_rgba(255,85,0,0.3)] text-white font-bold transition-all text-sm disabled:opacity-50 flex items-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      {t.save}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
