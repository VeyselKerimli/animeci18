import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, MessageSquare, Clock, User, Heart, AlertCircle, Share2 } from 'lucide-react';
import { Video, Comment, Language } from '../types';
import VideoPlayer from './VideoPlayer';

interface VideoDetailModalProps {
  video: Video;
  language: Language;
  onClose: () => void;
  onLike: (id: string) => void;
  hasLiked: boolean;
  comments: Comment[];
  onAddComment: (videoId: string, userName: string, text: string) => void;
  currentUser: any;
  userProfile: any;
  onAuthOpen: () => void;
}

export default function VideoDetailModal({
  video,
  language,
  onClose,
  onLike,
  hasLiked,
  comments,
  onAddComment,
  currentUser,
  userProfile,
  onAuthOpen,
}: VideoDetailModalProps) {
  const [commentText, setCommentText] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Auto scroll to video top on load
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  const t = {
    TR: {
      commentsTitle: 'Yorumlar',
      noComments: 'Henüz yorum yapılmamış. İlk yorumu siz yapın!',
      placeholderText: 'Yorumunuzu buraya yazın...',
      submitBtn: 'Yorum Yap',
      writeCommentTitle: 'Bir Yorum Bırakın',
      requiredError: 'Lütfen yorumunuzu girin.',
      backToBrowse: 'Geri Dön',
      loginRequired: 'Yorum yapmak için lütfen giriş yapın.',
      loginBtn: 'Giriş Yap veya Kayıt Ol',
    },
    EN: {
      commentsTitle: 'Comments',
      noComments: 'No comments yet. Be the first to comment!',
      placeholderText: 'Write your comment here...',
      submitBtn: 'Post Comment',
      writeCommentTitle: 'Leave a Comment',
      requiredError: 'Please enter your comment.',
      backToBrowse: 'Back to Browse',
      loginRequired: 'Please log in to leave a comment.',
      loginBtn: 'Login or Register',
    },
  }[language];

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) {
      setErrorMsg(t.requiredError);
      return;
    }
    
    const displayName = userProfile?.name || currentUser?.email?.split('@')[0] || 'Anonim';
    onAddComment(video.id, displayName, commentText.trim());
    setCommentText('');
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-40 bg-black/95 backdrop-blur-xl flex justify-center overflow-y-auto px-4 py-6 md:p-10">
      {/* Background glow */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-brand-primary/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="w-full max-w-5xl relative z-10">
        {/* Floating Close Button */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={onClose}
            className="flex items-center gap-2 bg-[#0F0F0F] hover:bg-[#141414] border border-white/5 hover:border-white/10 px-4 py-2.5 rounded-full text-sm font-semibold text-gray-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>{t.backToBrowse}</span>
          </button>
        </div>

        {/* Video Player + Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Video Section */}
          <div className="lg:col-span-2">
            <VideoPlayer
              video={video}
              language={language}
              onLike={() => onLike(video.id)}
              hasLiked={hasLiked}
            />
          </div>

          {/* Interactive Comments Panel */}
          <div className="lg:col-span-1 bg-[#0F0F0F]/90 border border-white/5 rounded-2xl p-5 md:p-6 flex flex-col max-h-[80vh] md:max-h-none overflow-hidden">
            <div className="flex items-center gap-2 border-b border-white/5 pb-4 mb-4">
              <MessageSquare className="w-5 h-5 text-brand-primary" />
              <h3 className="text-lg font-bold text-white tracking-tight">
                {t.commentsTitle} ({comments.length})
              </h3>
            </div>

            {/* Scrollable comments list */}
            <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1 max-h-[350px] lg:max-h-[40vh] scrollbar-thin">
              {comments.length === 0 ? (
                <div className="text-center py-10 text-gray-500 text-sm">
                  <MessageSquare className="w-8 h-8 text-gray-700 mx-auto mb-2" />
                  <p>{t.noComments}</p>
                </div>
              ) : (
                comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="bg-[#141414]/80 border border-white/5 rounded-xl p-3.5 space-y-1"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 font-bold text-gray-200">
                        <User className="w-3.5 h-3.5 text-brand-primary" />
                        <span className="truncate max-w-[120px]">{comment.userName}</span>
                      </div>
                      <div className="flex items-center gap-1 text-gray-500 font-medium">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          {new Date(comment.createdAt).toLocaleDateString(
                            language === 'TR' ? 'tr-TR' : 'en-US',
                            { hour: '2-digit', minute: '2-digit' }
                          )}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300 leading-relaxed break-words pt-1">
                      {comment.text}
                    </p>
                  </div>
                ))
              )}
            </div>

            {/* Write comment section */}
            {currentUser ? (
              <form onSubmit={handleSubmitComment} className="border-t border-white/5 pt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-brand-accent uppercase tracking-wider">
                    {t.writeCommentTitle}
                  </h4>
                  <span className="text-[10px] text-gray-500 font-semibold">
                    {language === 'TR' ? 'Şununla yorum yap:' : 'Commenting as:'} <span className="text-brand-primary">{userProfile?.name || currentUser.email.split('@')[0]}</span>
                  </span>
                </div>

                {errorMsg && (
                  <p className="text-red-500 text-xs flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errorMsg}
                  </p>
                )}

                <div className="relative">
                  <textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder={t.placeholderText}
                    maxLength={500}
                    className="w-full bg-[#141414] border border-white/5 focus:border-brand-primary focus:outline-none rounded-xl px-3.5 py-2.5 text-sm text-white h-20 resize-none pr-10"
                    required
                  />
                  <button
                    type="submit"
                    className="absolute right-2 bottom-3 w-8 h-8 rounded-lg bg-brand-primary hover:bg-brand-accent text-white flex items-center justify-center transition-colors cursor-pointer"
                    title={t.submitBtn}
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : (
              <div className="border-t border-white/5 pt-5 text-center space-y-3">
                <p className="text-xs text-gray-400 font-medium">
                  {t.loginRequired}
                </p>
                <button
                  type="button"
                  onClick={onAuthOpen}
                  className="w-full bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_15px_rgba(255,85,0,0.3)] text-white font-bold py-2.5 rounded-xl text-xs transition-all cursor-pointer"
                >
                  {t.loginBtn}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
