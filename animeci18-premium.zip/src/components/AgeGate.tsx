import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Globe } from 'lucide-react';
import { Language } from '../types';

interface AgeGateProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  onVerify: () => void;
}

export default function AgeGate({ language, setLanguage, onVerify }: AgeGateProps) {
  const handleReject = () => {
    window.location.href = 'https://www.google.com';
  };

  const translations = {
    TR: {
      title: 'Yetişkin İçerik Uyarısı',
      question: '18 yaşından büyük müsünüz?',
      desc: 'Bu platform yetişkinlere özel anime ve video içerikleri barındırmaktadır. Devam etmek için reşit olduğunuzu onaylamanız gerekmektedir.',
      yes: 'Evet, 18 Yaşından Büyüğüm',
      no: 'Hayır, Ayrılmak İstiyorum',
      footer: 'Animeci18 Premium topluluk kurallarına ve yasal mevzuatlara tabidir.',
    },
    EN: {
      title: 'Adult Content Warning',
      question: 'Are you over 18?',
      desc: 'This platform contains adult anime and video content. You must confirm you are of legal age to proceed.',
      yes: 'Yes, I am over 18',
      no: 'No, I want to leave',
      footer: 'Animeci18 Premium is subject to community guidelines and legal regulations.',
    },
  };

  const t = translations[language];

  return (
    <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#050505] text-white px-4">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] md:w-[600px] h-[350px] md:h-[600px] bg-brand-primary/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Language selector in age gate */}
      <div className="absolute top-6 right-6">
        <button
          onClick={() => setLanguage(language === 'TR' ? 'EN' : 'TR')}
          className="flex items-center gap-2 bg-[#141414] hover:bg-[#1f1f1f] border border-white/10 hover:border-brand-primary/40 px-4 py-2 rounded-full text-sm font-medium transition-all duration-300"
        >
          <Globe className="w-4 h-4 text-brand-primary" />
          <span>{language === 'TR' ? 'English (EN)' : 'Türkçe (TR)'}</span>
        </button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="w-full max-w-lg bg-[#0F0F0F]/90 backdrop-blur-xl border border-white/5 p-8 md:p-10 rounded-3xl shadow-2xl text-center relative overflow-hidden"
      >
        {/* Subtle orange border top accent */}
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-brand-primary to-brand-accent" />

        <div className="mx-auto w-16 h-16 bg-brand-primary/10 rounded-2xl flex items-center justify-center mb-6">
          <ShieldAlert className="w-8 h-8 text-brand-primary animate-pulse" />
        </div>

        <h1 className="text-sm tracking-widest text-brand-primary font-bold uppercase mb-2">
          {t.title}
        </h1>
        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight mb-4 text-white">
          {t.question}
        </h2>
        <p className="text-gray-400 text-sm md:text-base leading-relaxed mb-8">
          {t.desc}
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            id="btn-age-confirm"
            onClick={onVerify}
            className="flex-1 bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_20px_rgba(255,85,0,0.4)] text-white font-bold py-3.5 px-6 rounded-xl transition-all duration-300 transform active:scale-95"
          >
            {t.yes}
          </button>
          <button
            id="btn-age-reject"
            onClick={handleReject}
            className="flex-1 bg-[#1A1A1A] hover:bg-[#252525] text-gray-300 hover:text-white border border-white/10 font-semibold py-3.5 px-6 rounded-xl transition-all duration-300 transform active:scale-95"
          >
            {t.no}
          </button>
        </div>

        <p className="text-xs text-gray-500 mt-8 leading-normal border-t border-white/5 pt-6">
          {t.footer}
        </p>
      </motion.div>
    </div>
  );
}
