import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Lock, User, AlertCircle, Sparkles, CheckCircle } from 'lucide-react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, set } from 'firebase/database';
import { auth, database } from '../firebase';
import { Language } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export default function AuthModal({ isOpen, onClose, language }: AuthModalProps) {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const t = {
    TR: {
      login: 'Giriş Yap',
      register: 'Kayıt Ol',
      email: 'E-posta Adresi',
      pass: 'Şifre',
      name: 'Adınız / Takma Adınız',
      wrongCreds: 'E-posta adresi veya şifre hatalı.',
      loading: 'İşlem yapılıyor...',
      successReg: 'Başarıyla kayıt olundu! Şimdi giriş yapabilirsiniz.',
      successLog: 'Giriş başarılı!',
      promptLog: 'Zaten bir hesabınız var mı? Giriş Yap',
      promptReg: 'Hesabınız yok mu? Kayıt Ol',
      desc: 'Topluluğumuza katılın, yorum yapın ve favori animelerinizi kaydedin.',
    },
    EN: {
      login: 'Login',
      register: 'Register',
      email: 'Email Address',
      pass: 'Password',
      name: 'Your Name / Nickname',
      wrongCreds: 'Incorrect email or password.',
      loading: 'Processing...',
      successReg: 'Registered successfully! You can now log in.',
      successLog: 'Login successful!',
      promptLog: 'Already have an account? Login',
      promptReg: "Don't have an account? Register",
      desc: 'Join our community, write comments, and track your liked anime.',
    },
  }[language];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    try {
      if (activeTab === 'login') {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        setSuccessMsg(t.successLog);
        setTimeout(() => {
          onClose();
          // Reset fields
          setEmail('');
          setPassword('');
          setName('');
          setSuccessMsg('');
        }, 1000);
      } else {
        if (!name.trim()) {
          throw new Error(language === 'TR' ? 'Lütfen isminizi girin.' : 'Please enter your name.');
        }
        const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        const user = userCredential.user;

        // Save username and profile to RTDB
        await set(ref(database, `users/${user.uid}`), {
          uid: user.uid,
          name: name.trim(),
          email: email.trim(),
          isAdmin: email.trim() === 'veyselogrt@gmail.com', // automatically set the requested account as admin
          createdAt: new Date().toISOString(),
        });

        setSuccessMsg(t.successReg);
        setActiveTab('login');
        setPassword('');
      }
    } catch (error: any) {
      console.error(error);
      let msg = error.message;
      if (error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') {
        msg = t.wrongCreds;
      } else if (error.code === 'auth/email-already-in-use') {
        msg = language === 'TR' ? 'Bu e-posta adresi zaten kullanımda.' : 'This email address is already in use.';
      } else if (error.code === 'auth/weak-password') {
        msg = language === 'TR' ? 'Şifre en az 6 karakter olmalıdır.' : 'Password must be at least 6 characters.';
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      {/* Background glow */}
      <div className="absolute w-[300px] h-[300px] bg-brand-primary/10 rounded-full blur-[100px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-md bg-[#0F0F0F] border border-white/10 rounded-2xl overflow-hidden shadow-2xl relative"
      >
        {/* Top accent border */}
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-brand-primary to-brand-accent" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 rounded-full hover:bg-white/5 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tabs */}
        <div className="flex border-b border-white/5 bg-[#141414] px-6 pt-6">
          <button
            onClick={() => {
              setActiveTab('login');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`flex-1 pb-4 text-sm font-bold border-b-2 transition-all ${
              activeTab === 'login'
                ? 'border-brand-primary text-white'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            {t.login}
          </button>
          <button
            onClick={() => {
              setActiveTab('register');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`flex-1 pb-4 text-sm font-bold border-b-2 transition-all ${
              activeTab === 'register'
                ? 'border-brand-primary text-white'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            {t.register}
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="text-center pb-2">
            <h3 className="text-white font-extrabold text-lg flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4 text-brand-primary" />
              animeci<span className="text-brand-primary">18</span>
            </h3>
            <p className="text-xs text-gray-400 mt-1">
              {t.desc}
            </p>
          </div>

          {errorMsg && (
            <div className="bg-red-950/40 border border-red-900/30 text-red-400 p-3.5 rounded-xl flex items-center gap-2.5 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="bg-green-950/40 border border-green-900/30 text-green-400 p-3.5 rounded-xl flex items-center gap-2.5 text-xs">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Name Field (only for register) */}
          <AnimatePresence>
            {activeTab === 'register' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-1.5"
              >
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">
                  {t.name}
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#141414] border border-white/5 focus:border-brand-primary focus:outline-none rounded-xl pl-10 pr-4 py-3 text-sm text-white"
                    placeholder="Eren Yeager"
                    required={activeTab === 'register'}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Email Field */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">
              {t.email}
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#141414] border border-white/5 focus:border-brand-primary focus:outline-none rounded-xl pl-10 pr-4 py-3 text-sm text-white"
                placeholder="ornek@domain.com"
                required
              />
            </div>
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">
              {t.pass}
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#141414] border border-white/5 focus:border-brand-primary focus:outline-none rounded-xl pl-10 pr-4 py-3 text-sm text-white"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-brand-primary to-brand-accent hover:shadow-[0_0_15px_rgba(255,85,0,0.3)] text-white font-bold py-3 rounded-xl transition-all disabled:opacity-50 text-sm cursor-pointer mt-2"
          >
            {loading ? t.loading : activeTab === 'login' ? t.login : t.register}
          </button>

          {/* Helper Switch links */}
          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => {
                setActiveTab(activeTab === 'login' ? 'register' : 'login');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className="text-xs text-brand-accent hover:text-brand-primary font-semibold transition-colors"
            >
              {activeTab === 'login' ? t.promptReg : t.promptLog}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
