import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyAoqTkgibBuFO2PIHmWxFIgYMAf1TGpMmw",
  authDomain: "animeci18.firebaseapp.com",
  projectId: "animeci18",
  storageBucket: "animeci18.firebasestorage.app",
  messagingSenderId: "1080021587395",
  appId: "1:1080021587395:web:db21122150399b75985976",
  measurementId: "G-W4YM37099C"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const database = getDatabase(app);
